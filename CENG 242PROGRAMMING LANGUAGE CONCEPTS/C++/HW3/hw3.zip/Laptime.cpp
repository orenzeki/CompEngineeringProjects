#include "Laptime.h"
#include <iostream>
using namespace std;

/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE 
*/


bool Laptime::operator<(const Laptime& r) const{
    if (laptime < r.laptime){
        return true;
    }
	else{
        return false;
    }
 }
 bool Laptime::operator>(const Laptime& r) const{
    if (laptime > r.laptime){
        return true;
    }
	else{
        return false;
    }
 }
 Laptime& Laptime::operator+(const Laptime& r)
 {
 	laptime = (laptime)+r.laptime;
 	return (*this);
 }
 std::ostream& operator<<(std::ostream& os, const Laptime& lap){
     int minute = lap.laptime/60000;
     int second = lap.laptime-(minute*60000);
     second = second/1000;
     int milisecond = (lap.laptime-(minute*60000))-(second*1000);
     if(second < 10 && milisecond < 10){
        os << minute << ":0" << second << ".00" << milisecond;
     }
     else if(second < 10 && milisecond >= 10 && milisecond<100){
        os << minute << ":0" << second << ".0" << milisecond;
     }
     else if(second < 10 && milisecond >= 100){
        os << minute << ":0" << second << "." << milisecond;
     }
     else if(second >= 10 && milisecond < 10){
        os << minute << ":" << second << ".00" << milisecond;
     }
     else if(second >= 10 && milisecond >= 10 && milisecond<100){
        os << minute << ":" << second << ".0" << milisecond;
     }
     else{
        os << minute << ":" << second << "." << milisecond;
     }
     
     return os;
 }
Laptime::Laptime(int lt){
    laptime=lt;
    next=NULL;
}
Laptime::Laptime(const Laptime& r){
    laptime = r.laptime;
    next = r.next;
}
void Laptime::addLaptime(Laptime *nextval){
    Laptime* temp = this;
    if(temp == NULL){
        temp = nextval;
    }
    else {
        while(temp->next != NULL){
        temp = temp->next;
        }
        temp->next = nextval;
    }
}
Laptime* Laptime:: getNext() const{
    return (this->next);
}
int Laptime::getValue() const{
	return this->laptime;
}
void Laptime::setValue(int param){
	laptime = param;
}
void Laptime::setNext(Laptime *n){
	next= n;
}
Laptime::~Laptime(){

}
