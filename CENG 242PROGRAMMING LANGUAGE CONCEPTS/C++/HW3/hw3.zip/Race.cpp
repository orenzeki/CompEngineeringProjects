#include "Race.h"
#include "Car.h"
#include "Utilizer.h"
#include <iostream>
#include <string>
#include <vector>
using namespace std;

Race::Race(std::string rname):race_name(rname),average_laptime(Utilizer::generateAverageLaptime()),head(NULL){
    race_name=rname;
    average_laptime = Utilizer::generateAverageLaptime();
    head = NULL;
}
std::string Race::getRaceName() const{
    return race_name;
}
Race::~Race(){

}
Race::Race(const Race& r):race_name(r.race_name),average_laptime(r.average_laptime),head(r.head){
    race_name = r.race_name;
    average_laptime = r.average_laptime;
    head = r.head;
}
void addCartoRace(){
    Car *mycar = new Car("zeki oren");
}

/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE 
*/
