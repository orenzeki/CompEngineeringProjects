#include "Car.h"
#include "Utilizer.h"
#include <iostream>
#include <string>
#include <vector>
using namespace std;


Car::Car(std::string dname){
    driver_name=dname;
    next=NULL;
    head = NULL;
    performance=Utilizer::generatePerformance();
}
Car::Car(const Car& r){
    driver_name = r.driver_name;
    next = r.next;
    head = r.head;
    performance = r.performance;
}
Car::~Car(){

}
string Car::getDriverName() const{
    return driver_name;
}

double Car::getPerformance() const{
    return performance;
}
void Car::addCar(Car *nextval){
    Car* temp = this;
    while(temp->next != NULL){
        temp = temp->next;
    }
    temp->next = nextval;
}

bool Car::operator<(const Car& r) const{
    int total1=0;
    Laptime* first = head;
    while(first != NULL){
        total1 += first->getValue();
        first = first->getNext();
    }
    int total2=0;
    Laptime* second = r.head;
    while(second != NULL){
        total2 += second->getValue();
        second = second->getNext();
    }

    if (total1 < total2){
        return true;
    }
	else{
        return false;
    }
}
bool Car::operator>(const Car& r) const{
    int total1=0;
    Laptime* first = head;
    while(first != NULL){
        total1 += first->getValue();
        first = first->getNext();
    }
    int total2=0;
    Laptime* second = r.head;
    while(second != NULL){
        total2 += second->getValue();
        second = second->getNext();
    }
    if (total1 > total2){
        return true;
    }
	else{
        return false;
    }
}
Laptime Car::operator[](const int lap) const{

    Laptime* temp = head;
    if(head->getLength()<lap){
        return 0;
    }
    else{
        for(int i=0; i<lap; i++){
        temp = temp->getNext();
        }
        return temp->getValue();
    }
}
void Car::Lap(const Laptime& avglap){
    int temp = Utilizer::generateLaptimeVariance(performance);
    int temp2 = avglap.getValue();
    int temp3 = temp + temp2;
    Laptime* lapt = new Laptime(temp3);
    if (head == NULL){
        head=lapt;
    }
    else{
        head->addLaptime(lapt);
    }
}
std::ostream& operator<<(std::ostream& os, const Car& car){
    string fullname = car.driver_name;
    int index=0;
    for(int i=0; i<fullname.length();i++)
    {
        if(fullname.at(i) == ' '){
            index = i+1;
            i = fullname.length();
        }
    }
    char letter1 = fullname.at(index);
    letter1 = toupper(letter1);
    index++;
    char letter2 = fullname.at(index);
    letter2 = toupper(letter2);
    index++;
    char letter3 = fullname.at(index);
    letter3 = toupper(letter3);

    Laptime* latest = car.head;
    while(latest->getNext() != NULL){
        latest = latest->getNext();
    }

    Laptime* findfast = car.head;
    Laptime* fastest = car.head;
    while(findfast != NULL){
        
        if(*findfast < *fastest){
            fastest = findfast;
        }
        findfast = findfast->getNext();
    }
    Laptime* total = car.head;
    int tot=0;
    while(total != NULL){
        tot += total->getValue();
        total = total->getNext();
    }
    os << letter1 << letter2 << letter3 << "--" << *latest << "--" << *fastest << "--" << Laptime(tot);
    return os;

}


/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE 
*/

