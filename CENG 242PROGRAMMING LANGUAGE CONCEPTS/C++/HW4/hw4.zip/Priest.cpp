#include"Priest.h"
#include"Player.h"
#include <string>

using namespace std;
/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE
*/
 Priest::Priest(uint id,int x, int y, Team team):Player(id,x,y,team){
     HP = 150;
 }
 
 int Priest::getAttackDamage() const{
     return 0;
 }
 int Priest::getHealPower() const{
     return 50;
 }
 int Priest::getMaxHP() const{
     return 150;
 }
std::vector<Goal> Priest::getGoalPriorityList(){
    vector<Goal> goal;
    goal.push_back(HEAL);
    goal.push_back(TO_ALLY);
    goal.push_back(CHEST);
    return goal;
 }
 const std::string Priest::getClassAbbreviation() const{
    if(team == 0)
        return upperab;
    else
        return lowerab;
 }
 std::vector<Coordinate> Priest::getAttackableCoordinates(){
    vector<Coordinate> coord;
    return coord;
 }
 std::vector<Coordinate> Priest::getMoveableCoordinates(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    Coordinate coor3 = coordinate + Coordinate(-1,0);
    Coordinate coor4 = coordinate + Coordinate(1,0);
    Coordinate coor5 = coordinate + Coordinate(-1,-1);
    Coordinate coor6 = coordinate + Coordinate(-1,1);
    Coordinate coor7 = coordinate + Coordinate(1,-1);
    Coordinate coor8 = coordinate + Coordinate(1,1);

    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    coord.push_back(coor3);
    coord.push_back(coor4);
    coord.push_back(coor5);
    coord.push_back(coor6);
    coord.push_back(coor7);
    coord.push_back(coor8);

    return coord;
 }
 std::vector<Coordinate> Priest::getHealableCoordinates(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    Coordinate coor3 = coordinate + Coordinate(-1,0);
    Coordinate coor4 = coordinate + Coordinate(1,0);
    Coordinate coor5 = coordinate + Coordinate(-1,-1);
    Coordinate coor6 = coordinate + Coordinate(-1,1);
    Coordinate coor7 = coordinate + Coordinate(1,-1);
    Coordinate coor8 = coordinate + Coordinate(1,1);

    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    coord.push_back(coor3);
    coord.push_back(coor4);
    coord.push_back(coor5);
    coord.push_back(coor6);
    coord.push_back(coor7);
    coord.push_back(coor8);

    return coord;
 }
 std::vector<Coordinate> Priest::diagonals(){
    Coordinate coor1 = coordinate + Coordinate(-1,-1);
    Coordinate coor2 = coordinate + Coordinate(-1,1);
    Coordinate coor3 = coordinate + Coordinate(1,-1);
    Coordinate coor4 = coordinate + Coordinate(1,1);
    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    coord.push_back(coor3);
    coord.push_back(coor4);
    return coord;
 }
 std::vector<Coordinate> Priest::horizontals(){
    Coordinate coor1 = coordinate + Coordinate(-1,0);
    Coordinate coor2 = coordinate + Coordinate(1,0);
    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    return coord;
 }
 std::vector<Coordinate> Priest::verticals(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    return coord;
 }