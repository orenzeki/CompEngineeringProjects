#include"Board.h"

/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE
*/
Board::Board(uint _size, std::vector<Player*>* _players, Coordinate chest):size(_size),players(_players),chest(chest){}

Board::~Board(){}

bool Board::isCoordinateInBoard(const Coordinate& c){
    if(c<getBoardCoordinates() && Coordinate(0,0)<c)
        return true;
    else
        return false;
}

bool Board::isPlayerOnCoordinate(const Coordinate& c){
    for(int i=0; i<players->size(); i++){
        if(players->at(i)->getCoord() == c)
            return true;
    }
    return false;
}

Player *Board::operator [](const Coordinate& c){
    for(int i=0; i<players->size(); i++){
        if(players->at(i)->getCoord() == c)
            return players->at(i);
    }
    return NULL;
}

Coordinate Board::getChestCoordinates(){
    return chest;
}

void Board::printBoardwithID(){
    int flag = 0;
    string pid;
    for (int i=0; i<size; i++){
        for(int j=0; j<size; j++){
            if(chest == Coordinate(j,i)){
                    flag = 1;
                    pid = "Ch";
            }
            for(int k=0; k<players->size(); k++){
                if(players->at(k)->getCoord() == Coordinate(j,i)){
                    flag = 1;
                    pid = players->at(k)->getBoardID();
                }
            }
            if(flag){
                cout << pid << " ";
                flag = 0;
                pid = " ";
            }
            else{
                cout << "__ ";
            }
           
        }
        cout << endl;
    }
}

void Board::printBoardwithClass(){
    int flag = 0;
    string pid;
    for (int l=0; l<size; l++){
        for(int m=0; m<size; m++){
            if((chest == Coordinate(m,l))){
                    flag = 1;
                    pid = "Ch";
            }
            for(int n=0; n<players->size(); n++){
                if(players->at(n)->getCoord() == Coordinate(m,l)){
                    flag = 1;
                    pid = players->at(n)->getClassAbbreviation();
                }
            }
            if(flag){
                cout << pid << " ";
                flag = 0;
                pid = " ";
            }
            else{
                cout << "__ ";
            }
           
        }
        cout << endl;
    }
}

Coordinate Board::getBoardCoordinates(){
    Coordinate coor = Coordinate(size-1,size-1);
    return coor;
}