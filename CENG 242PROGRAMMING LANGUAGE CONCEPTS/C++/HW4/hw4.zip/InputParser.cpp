#include"InputParser.h"

/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE
*/
 Game* InputParser::parseGame(){

    int  x, y, pnum, pid, xcoor, ycoor;
    uint bsize, maxnum;
    string cls, teamstr;
    Team team;
  
    Game *game;

    cin >> bsize;
   
    cin >> x;
    cin >> y;
    Coordinate chs(x,y);

    cin >> maxnum;
    cin >> pnum;
    game = new Game(maxnum,bsize,chs);

    for(int i=0; i<pnum; i++){
        cin >> pid;
        cin >> cls;
        cin >> teamstr;
        cin >> xcoor;
        cin >> ycoor;

        if(teamstr == "BARBARIAN")
            team = BARBARIANS;
        else
            team = KNIGHTS;

        game->addPlayer(pid, xcoor, ycoor, team, cls);    
    }
    return game;
}