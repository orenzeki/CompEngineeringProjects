#include"Scout.h"
#include <string>

using namespace std;
/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE
*/
 Scout::Scout(uint id,int x, int y, Team team):Player(id,x,y,team){
     HP = 125;
 }
 
 int Scout::getAttackDamage() const{
     return 25;
 }
 int Scout::getHealPower() const{
     return 0;
 }
 int Scout::getMaxHP() const{
     return 125;
 }
std::vector<Goal> Scout::getGoalPriorityList(){
    vector<Goal> goal;
    goal.push_back(CHEST);
    goal.push_back(TO_ALLY);
    goal.push_back(ATTACK);
    return goal;
 }
 const std::string Scout::getClassAbbreviation() const{
    if(team == 0)
        return upperab;
    else
        return lowerab;
 }
 std::vector<Coordinate> Scout::getAttackableCoordinates(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    Coordinate coor3 = coordinate + Coordinate(-1,0);
    Coordinate coor4 = coordinate + Coordinate(1,0);
    Coordinate coor5 = coordinate + Coordinate(-1,-1);
    Coordinate coor6 = coordinate + Coordinate(-1,1);
    Coordinate coor7 = coordinate + Coordinate(1,-1);
    Coordinate coor8 = coordinate + Coordinate(1,1);

    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    coord.push_back(coor3);
    coord.push_back(coor4);
    coord.push_back(coor5);
    coord.push_back(coor6);
    coord.push_back(coor7);
    coord.push_back(coor8);

    return coord;
 }
 std::vector<Coordinate> Scout::getMoveableCoordinates(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    Coordinate coor3 = coordinate + Coordinate(-1,0);
    Coordinate coor4 = coordinate + Coordinate(1,0);
    Coordinate coor5 = coordinate + Coordinate(-1,-1);
    Coordinate coor6 = coordinate + Coordinate(-1,1);
    Coordinate coor7 = coordinate + Coordinate(1,-1);
    Coordinate coor8 = coordinate + Coordinate(1,1);

    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    coord.push_back(coor3);
    coord.push_back(coor4);
    coord.push_back(coor5);
    coord.push_back(coor6);
    coord.push_back(coor7);
    coord.push_back(coor8);

    return coord;
 }
 std::vector<Coordinate> Scout::getHealableCoordinates(){
    vector<Coordinate> coord;
    return coord;
 }
 std::vector<Coordinate> Scout::diagonals(){
    Coordinate coor1 = coordinate + Coordinate(-1,-1);
    Coordinate coor2 = coordinate + Coordinate(-1,1);
    Coordinate coor3 = coordinate + Coordinate(1,-1);
    Coordinate coor4 = coordinate + Coordinate(1,1);
    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    coord.push_back(coor3);
    coord.push_back(coor4);
    return coord;
 }
 std::vector<Coordinate> Scout::horizontals(){
    Coordinate coor1 = coordinate + Coordinate(-1,0);
    Coordinate coor2 = coordinate + Coordinate(1,0);
    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    return coord;
 }
 std::vector<Coordinate> Scout::verticals(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    return coord;
 }