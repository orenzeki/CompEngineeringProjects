#include"Tank.h"
#include <string>

using namespace std;
/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE
*/
 Tank::Tank(uint id,int x, int y, Team team):Player(id,x,y,team){
     HP = 1000;
 }
 
 int Tank::getAttackDamage() const{
     return 25;
 }
 int Tank::getHealPower() const{
     return 0;
 }
 int Tank::getMaxHP() const{
     return 1000;
 }
std::vector<Goal> Tank::getGoalPriorityList(){
    vector<Goal> goal;
    goal.push_back(TO_ENEMY);
    goal.push_back(ATTACK);
    goal.push_back(CHEST);
    return goal;
 }
 const std::string Tank::getClassAbbreviation() const{
    if(team == 0)
        return upperab;
    else
        return lowerab;
 }
 std::vector<Coordinate> Tank::getAttackableCoordinates(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    Coordinate coor3 = coordinate + Coordinate(-1,0);
    Coordinate coor4 = coordinate + Coordinate(1,0);

    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    coord.push_back(coor3);
    coord.push_back(coor4);

    return coord;
 }
 std::vector<Coordinate> Tank::getMoveableCoordinates(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    Coordinate coor3 = coordinate + Coordinate(-1,0);
    Coordinate coor4 = coordinate + Coordinate(1,0);

    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    coord.push_back(coor3);
    coord.push_back(coor4);

    return coord;
 }
 std::vector<Coordinate> Tank::getHealableCoordinates(){
    vector<Coordinate> coord;
    return coord;
 }
  std::vector<Coordinate> Tank::diagonals(){
    vector<Coordinate> coord;
    return coord;
 }
 std::vector<Coordinate> Tank::horizontals(){
    Coordinate coor1 = coordinate + Coordinate(-1,0);
    Coordinate coor2 = coordinate + Coordinate(1,0);
    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    return coord;
 }
 std::vector<Coordinate> Tank::verticals(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    return coord;
 }