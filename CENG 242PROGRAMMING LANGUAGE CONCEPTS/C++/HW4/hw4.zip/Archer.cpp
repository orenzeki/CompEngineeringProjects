#include"Archer.h"
#include <string>

using namespace std;
/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE
*/
 Archer::Archer(uint id,int x, int y, Team team):Player(id,x,y,team){
     HP = 200;
 }
 
 int Archer::getAttackDamage() const{
     return 50;
 }
 int Archer::getHealPower() const{
     return 0;
 }
 int Archer::getMaxHP() const{
     return 200;
 }
std::vector<Goal> Archer::getGoalPriorityList(){
    vector<Goal> goal;
    goal.push_back(ATTACK);
    return goal;
 }
 const std::string Archer::getClassAbbreviation() const{
    if(team == 0)
        return upperab;
    else
        return lowerab;
 }
 std::vector<Coordinate> Archer::getAttackableCoordinates(){
    Coordinate coor1 = coordinate + Coordinate(0,-2);
    Coordinate coor2 = coordinate + Coordinate(0,2);
    Coordinate coor3 = coordinate + Coordinate(-2,0);
    Coordinate coor4 = coordinate + Coordinate(2,0);
    Coordinate coor5 = coordinate + Coordinate(0,-1);
    Coordinate coor6 = coordinate + Coordinate(0,1);
    Coordinate coor7 = coordinate + Coordinate(-1,0);
    Coordinate coor8 = coordinate + Coordinate(1,0);

    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    coord.push_back(coor3);
    coord.push_back(coor4);
    coord.push_back(coor5);
    coord.push_back(coor6);
    coord.push_back(coor7);
    coord.push_back(coor8);

    return coord;
 }
 std::vector<Coordinate> Archer::getMoveableCoordinates(){
     vector<Coordinate> coord;
     return coord;
 }
 std::vector<Coordinate> Archer::getHealableCoordinates(){
    vector<Coordinate> coord;
    return coord;
 }
 std::vector<Coordinate> Archer::diagonals(){
     vector<Coordinate> coord;
     return coord;
 }
 std::vector<Coordinate> Archer::horizontals(){
    vector<Coordinate> coord;
     return coord;
 }
 std::vector<Coordinate> Archer::verticals(){
    vector<Coordinate> coord;
     return coord;
 }

