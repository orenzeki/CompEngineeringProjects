#include"Game.h"
#include <vector>
/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE
*/
Game::Game(uint maxTurnNumber, uint boardSize, Coordinate chest):maxTurnNumber{maxTurnNumber},board(boardSize,&players,chest){
    turnNumber = 0;
}

Game::~Game(){}

void Game::addPlayer(int id, int x, int y, Team team, std::string cls){
    Player *newplayer;
    if(cls == "ARCHER"){
        newplayer = new Archer(id,x,y,team);
    }
    else if(cls == "FIGHTER"){
        newplayer = new Fighter(id,x,y,team);
    }
    else if(cls == "SCOUT"){
        newplayer = new Scout(id,x,y,team);
    }
    else if(cls == "TANK"){
        newplayer = new Tank(id,x,y,team);
    }
    else if(cls == "PRIEST"){
        newplayer = new Priest(id,x,y,team);
    }
    players.push_back(newplayer);
}

bool Game::isGameEnded(){
    if(maxTurnNumber == turnNumber){
        cout << "Game ended at turn " << turnNumber << ". Maximum turn number reached. Knight victory." << endl;
        return true;
    }
    int knights = 0;
    int barbarians = 0;
    for (int i=0; i<players.size(); i++){
        if(players.at(i)->getTeam() == BARBARIANS){
            barbarians++;
        }
        if(players.at(i)->getTeam() == KNIGHTS){
            knights++;
        }
        if((players.at(i)->getTeam() == BARBARIANS) && players.at(i)->getCoord() == board.getChestCoordinates()){
            cout << "Game ended at turn " << turnNumber << ". Chest captured. Barbarian victory." << endl;
            knights = 0;
            barbarians = 0;
            return true;
        }
    }
    if(!knights){
        cout << "Game ended at turn " << turnNumber << ". All knights dead. Barbarian victory." << endl;
        knights = 0;
        barbarians = 0;
        return true;
    }
    if(!barbarians){
        cout << "Game ended at turn " << turnNumber << ". All barbarians dead. Knight victory." << endl;
        knights = 0;
        barbarians = 0;
        return true;
    }
    return false;
}

void Game::playTurn(){
    turnNumber++;
    cout << "Turn " << turnNumber <<  " has started." << endl;
    int size1 = players.size();
    int size2 = size1;
    int index2;
    Player *minplayer = players.at(0);
    int index = 0;
    for(int k=0; k<size1; k++){
        for(int l=0; l<size2; l++){
            if(players.at(l)->getID() < minplayer->getID()){
                minplayer = players.at(l);
                index = l;
            }
        }
        players.erase(players.begin() + index);
        players.push_back(minplayer);
        index=0;
        minplayer = players.at(0);
        size2--;
    }
    for(int i=0; i<players.size(); i++){
        index2 = 0;
        playTurnForPlayer(players.at(i));
        if(players.at(i)->isDead()){
            for(int j=0; j<players.size(); j++){
                if(players.at(i)->getID() == players.at(j)->getID()){
                    index2 = j;
                }
            }
            cout << "Player " << players.at(index2)->getBoardID() << " has died." << endl;
            players.erase(players.begin() + index2);
            i--;
            
        }
        
    }

}

Goal Game::playTurnForPlayer(Player* player){
    if(player->isDead()){
        return NO_GOAL;
    }
    int index=-1;
    int id = 99999;
    for(int i=0; i<player->getGoalPriorityList().size(); i++){
        // ---------------------- ATTACK ----------------------
        if(player->getGoalPriorityList().at(i) == ATTACK){
            for(int j=0; j<player->getAttackableCoordinates().size(); j++){
                for(int k=0; k<players.size(); k++){
                    if((player->getAttackableCoordinates().at(j) == players.at(k)->getCoord()) && (player->getTeam() != players.at(k)->getTeam())){
                        if(players.at(k)->getID() < id){
                            index = k;
                            id = players.at(k)->getID();
                        }
                    }
                }
            }
            if(id != 99999){
                player->attack(players.at(index));
                return ATTACK;
            }
        }
        // ------------------- CHEST ----------------------
        else if(player->getGoalPriorityList().at(i) == CHEST){
            Coordinate movecoor = Coordinate(-1,-1);
            int range = 9999;
            int newflag = 0;

            for(int j=0; j<player->diagonals().size(); j++){
                if((player->diagonals().at(j) - board.getChestCoordinates()) < range){
                    for(int k=0; k<players.size(); k++){
                        if(player->diagonals().at(j) == players.at(k)->getCoord()){
                            newflag = 1;
                        }
                    }
                    if(!newflag){
                        range = player->diagonals().at(j) - board.getChestCoordinates();
                        movecoor = player->diagonals().at(j);
                    }
                    else{
                        newflag = 0;
                    }
                }
            }
            for(int j=0; j<player->horizontals().size(); j++){
                if((player->horizontals().at(j) - board.getChestCoordinates()) < range){
                    for(int k=0; k<players.size(); k++){
                        if(player->horizontals().at(j) == players.at(k)->getCoord()){
                            newflag = 1;
                        }
                    }
                    if(!newflag){
                        range = player->horizontals().at(j) - board.getChestCoordinates();
                        movecoor = player->horizontals().at(j);
                    }
                    else{
                        newflag = 0;
                    }
                }
            }
            for(int j=0; j<player->verticals().size(); j++){
                if((player->verticals().at(j) - board.getChestCoordinates()) < range){
                    for(int k=0; k<players.size(); k++){
                        if(player->verticals().at(j) == players.at(k)->getCoord()){
                            newflag = 1;
                        }
                    }
                    if(!newflag){
                        range = player->verticals().at(j) - board.getChestCoordinates();
                        movecoor = player->verticals().at(j);
                    }
                    else{
                        newflag = 0;
                    }
                }
            }
            if(movecoor != Coordinate(-1,-1)){
                    player->movePlayerToCoordinate(movecoor);
                return CHEST;
            }
        }
        // --------- TO_ENEMY -----------------
        else if(player->getGoalPriorityList().at(i) == TO_ENEMY){
            int returnflag = 0;
            for(int m=0; m<players.size(); m++){
                for(int n=0; n<player->getAttackableCoordinates().size(); n++){
                    if((player->getAttackableCoordinates().at(n) == players.at(m)->getCoord()) && (players.at(m)->getTeam() != player->getTeam())){
                        returnflag = 1;
                    }
                }
            }
            if(!returnflag){
                Coordinate movecoord = Coordinate(-1,-1);
                Coordinate enemycoor = Coordinate(-1,-1);
                int enemyflag = 0;
                int id = 9999;
                int range = 9999;
                for(int j=0; j<players.size(); j++){
                    for(int k=0; k<player->getMoveableCoordinates().size(); k++){
                        if(((player->getMoveableCoordinates().at(k) - players.at(j)->getCoord()) < range) && (players.at(j)->getTeam() != player->getTeam())){
                            enemycoor = players.at(j)->getCoord();
                            range = (player->getMoveableCoordinates().at(k) - players.at(j)->getCoord());
                            id = players.at(j)->getID();
                        }
                        if(((player->getMoveableCoordinates().at(k) - players.at(j)->getCoord()) == range) && (players.at(j)->getID() < id) && (players.at(j)->getTeam() != player->getTeam())){
                            enemycoor = players.at(j)->getCoord();
                            range = (player->getMoveableCoordinates().at(k) - players.at(j)->getCoord());
                            id = players.at(j)->getID();
                        }
                
                    }
                }
                range = 9999;
                for(int j=0; j<player->diagonals().size(); j++){
                    if((player->diagonals().at(j) - enemycoor) < range){
                        for(int k=0; k<players.size(); k++){
                            if(player->diagonals().at(j) == players.at(k)->getCoord()){
                                enemyflag = 1;
                            }
                        }
                        if(!enemyflag){
                            range = player->diagonals().at(j) - enemycoor;
                            movecoord = player->diagonals().at(j);
                        }
                        else{
                            enemyflag = 0;
                        }
                    }
                }
                for(int j=0; j<player->horizontals().size(); j++){
                    if((player->horizontals().at(j) - enemycoor) < range){
                        for(int k=0; k<players.size(); k++){
                            if(player->horizontals().at(j) == players.at(k)->getCoord()){
                                enemyflag = 1;
                            }
                        }
                        if(!enemyflag){
                            range = player->horizontals().at(j) - enemycoor;
                            movecoord = player->horizontals().at(j);
                        }
                    else{
                            enemyflag = 0;
                        }
                    }
                }
                for(int a=0; a<player->verticals().size(); a++){
                    if((player->verticals().at(a) - enemycoor) < range){
                        for(int b=0; b<players.size(); b++){
                            if(player->verticals().at(a) == players.at(b)->getCoord()){
                                enemyflag = 1;
                            }
                        }
                        if(!enemyflag){
                            range = player->verticals().at(a) - enemycoor;
                            movecoord = player->verticals().at(a);
                        }
                        else{
                            enemyflag = 0;
                        }
                    }
                }
                if(movecoord != Coordinate(-1,-1)){
                    player->movePlayerToCoordinate(movecoord);
                    return TO_ENEMY;
                }
            }
        }
        // ------------------- TO_ALLY ------------------------
        else if(player->getGoalPriorityList().at(i) == TO_ALLY){
            int returnflag = 0;
            for(int m=0; m<players.size(); m++){
                for(int n=0; n<player->getHealableCoordinates().size(); n++){
                    if((player->getHealableCoordinates().at(n) == players.at(m)->getCoord()) && (players.at(m)->getTeam() == player->getTeam())){
                        returnflag = 1;
                    }
                }
            }
            if(!returnflag){
                Coordinate movecoordn = Coordinate(-1,-1);
                Coordinate allycoor = Coordinate(-1,-1);
                int allyflag = 0;
                int allyid = 9999;
                int allyrange = 9999;
                for(int j=0; j<players.size(); j++){
                    for(int k=0; k<player->getMoveableCoordinates().size(); k++){
                        if(((player->getMoveableCoordinates().at(k) - players.at(j)->getCoord()) < allyrange) && (players.at(j)->getTeam() == player->getTeam()) && (players.at(j)->getID() != player->getID())){
                            allycoor = players.at(j)->getCoord();
                            allyrange = (player->getMoveableCoordinates().at(k) - players.at(j)->getCoord());
                            allyid = players.at(j)->getID();
                        }
                        if(((player->getMoveableCoordinates().at(k) - players.at(j)->getCoord()) == allyrange) && (players.at(j)->getID() < allyid) && (players.at(j)->getTeam() == player->getTeam()) && (players.at(j)->getID() != player->getID())){
                            allycoor = players.at(j)->getCoord();
                            allyrange = (player->getMoveableCoordinates().at(k) - players.at(j)->getCoord());
                            allyid = players.at(j)->getID();
                        }
                
                    }
                }
                allyrange = 9999;
                for(int j=0; j<player->diagonals().size(); j++){
                    if((player->diagonals().at(j) - allycoor) < allyrange){
                        for(int k=0; k<players.size(); k++){
                            if(player->diagonals().at(j) == players.at(k)->getCoord()){
                            allyflag = 1;
                            }
                        }
                        if(!allyflag){
                            allyrange = player->diagonals().at(j) - allycoor;
                            movecoordn = player->diagonals().at(j);
                        }
                        else{
                            allyflag = 0;
                        }
                    }
                }
                for(int j=0; j<player->horizontals().size(); j++){
                    if((player->horizontals().at(j) - allycoor) < allyrange){
                        for(int k=0; k<players.size(); k++){
                            if(player->horizontals().at(j) == players.at(k)->getCoord()){
                                allyflag = 1;
                            }
                        }
                        if(!allyflag){
                            allyrange = player->horizontals().at(j) - allycoor;
                            movecoordn = player->horizontals().at(j);
                        }
                        else{
                            allyflag = 0;
                        }
                    }
                }
                for(int j=0; j<player->verticals().size(); j++){
                    if((player->verticals().at(j) - allycoor) < allyrange){
                        for(int k=0; k<players.size(); k++){
                            if(player->verticals().at(j) == players.at(k)->getCoord()){
                            allyflag = 1;
                            }
                        }
                        if(!allyflag){
                            allyrange = player->verticals().at(j) - allycoor;
                            movecoordn = player->verticals().at(j);
                        }
                        else{
                            allyflag = 0;
                        }
                    }
                }
                if(movecoordn != Coordinate(-1,-1)){
                    player->movePlayerToCoordinate(movecoordn);
                    return TO_ALLY;
                }
            }
        }
        // ------------------- HEAL ---------------------
        else if(player->getGoalPriorityList().at(i) == HEAL){
            int healflag = 0;
            for(int j=0; j<player->getHealableCoordinates().size(); j++){
                for(int k=0; k<players.size(); k++){
                    if((player->getHealableCoordinates().at(j) == players.at(k)->getCoord()) && (player->getTeam() == players.at(k)->getTeam())){
                        player->heal(players.at(k));
                        healflag = 1;
                    }
                }
            }
            if(healflag){
                healflag = 0;
                return HEAL;
            }
        }
    }
    return NO_GOAL;
}

