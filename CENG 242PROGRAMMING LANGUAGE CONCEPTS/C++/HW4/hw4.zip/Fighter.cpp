#include"Fighter.h"
#include <string>

using namespace std;
/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE
*/
 Fighter::Fighter(uint id,int x, int y, Team team):Player(id,x,y,team){
     HP = 400;
 }
 int Fighter::getAttackDamage() const{
     return 100;
 }
 int Fighter::getHealPower() const{
     return 0;
 }
 int Fighter::getMaxHP() const{
     return 400;
 }
std::vector<Goal> Fighter::getGoalPriorityList(){
    vector<Goal> goal;
    goal.push_back(ATTACK);
    goal.push_back(TO_ENEMY);
    goal.push_back(CHEST);
    return goal;
 }
 const std::string Fighter::getClassAbbreviation() const{
    if(team == 0)
        return upperab;
    else
        return lowerab;
 }
 std::vector<Coordinate> Fighter::getAttackableCoordinates(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    Coordinate coor3 = coordinate + Coordinate(-1,0);
    Coordinate coor4 = coordinate + Coordinate(1,0);

    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    coord.push_back(coor3);
    coord.push_back(coor4);

    return coord;
 }
 std::vector<Coordinate> Fighter::getMoveableCoordinates(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    Coordinate coor3 = coordinate + Coordinate(-1,0);
    Coordinate coor4 = coordinate + Coordinate(1,0);

    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    coord.push_back(coor3);
    coord.push_back(coor4);

    return coord;
 }
 std::vector<Coordinate> Fighter::getHealableCoordinates(){
    vector<Coordinate> coord;
    return coord;
 }
 std::vector<Coordinate> Fighter::diagonals(){
     vector<Coordinate> coord;
     return coord;
 }
 std::vector<Coordinate> Fighter::horizontals(){
    Coordinate coor1 = coordinate + Coordinate(-1,0);
    Coordinate coor2 = coordinate + Coordinate(1,0);
    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    return coord;
 }
 std::vector<Coordinate> Fighter::verticals(){
    Coordinate coor1 = coordinate + Coordinate(0,-1);
    Coordinate coor2 = coordinate + Coordinate(0,1);
    vector<Coordinate> coord;
    coord.push_back(coor1);
    coord.push_back(coor2);
    return coord;
 }
