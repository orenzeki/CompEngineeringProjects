#include "Player.h"
#include <vector>
#include <iostream>
#include <string>
#include "Constants.h"
#include "Coordinate.h"
using namespace std;

/*
YOU MUST WRITE THE IMPLEMENTATIONS OF THE REQUESTED FUNCTIONS
IN THIS FILE. START YOUR IMPLEMENTATIONS BELOW THIS LINE
*/

Player::Player(uint id, int x, int y, Team team):id(id),coordinate(x,y),team(team){}
uint Player::getID() const{
    return id;
}

const Coordinate &Player::getCoord() const{
     return coordinate;
}

int Player::getHP() const{
     return HP;
 }

Team Player::getTeam() const{
    return team;
}

std::string Player::getBoardID(){
    string newid = to_string(id);
    if (id<10)
        return  newid.insert (0, 1, '0');
    else
        return newid;
}


bool Player::attack(Player *enemy){
    enemy->HP -= getAttackDamage();
    cout <<"Player "<< getBoardID() <<  " attacked Player " << enemy->getBoardID() << " (" << getAttackDamage() << ")"<<endl; 
    if(HP<=0)
        return true;
    else
        return false;
}

void Player::heal(Player *ally){
    ally->HP += getHealPower();
    cout <<"Player "<< getBoardID() <<  " healed Player " << ally->getBoardID() <<endl; 
    if(HP > getMaxHP()){
        ally->HP = getMaxHP();
    }
}

void Player::movePlayerToCoordinate(Coordinate c){
    for (int i=0; i<getMoveableCoordinates().size(); i++){
        if(getMoveableCoordinates().at(i) == c){
            cout << "Player " << getBoardID() << " moved from " << coordinate << " to " << c <<endl;
            setCoordinate(c);
        }
    }
}

bool Player::isDead() const{
    if(HP <= 0)
        return true;
    else
        return false;
}

std::vector<Goal> Player::getGoalPriorityList(){}
const std::string Player::getClassAbbreviation() const{}
std::vector<Coordinate> Player::getAttackableCoordinates(){}
std::vector<Coordinate> Player::getHealableCoordinates(){}
std::vector<Coordinate> Player::getMoveableCoordinates(){}
int Player::getAttackDamage() const{}
int Player::getHealPower() const{}
int Player::getMaxHP() const{}
std::vector<Coordinate> Player::diagonals(){}   
std::vector<Coordinate> Player::horizontals(){} 
std::vector<Coordinate> Player::verticals(){}
